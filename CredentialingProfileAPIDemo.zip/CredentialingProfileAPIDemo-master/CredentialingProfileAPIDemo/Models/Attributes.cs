﻿namespace CredentialingProfileAPIDemo.Models
{
    public class Attributes
    {
        public string? Type { get; set; }
        public string? Url { get; set; }
    }
}

﻿using System.Net.NetworkInformation;

namespace CredentialingProfileAPIDemo.Models
{
    // Abstract base class for credentialing profiles
    public abstract class CredentialingProfile : BaseRequestBody
    {
        public string? Office_Address_Street_1__c { get; set; }
        public string? Office_Address_Street_2__c { get; set; }
        public string? Office_Address_City__c { get; set; }
        public string? Office_Address_Zipcode__c { get; set; }
        public string? Office_Address_State__c { get; set; }
        public string? Office_Address_County__c { get; set; }
        public bool Please_acknowledge_If_denied_credential__c { get; set; }
        public string? Summary_of_Changes__c { get; set; }
        public DateTime Submission_Date__c { get; set; }
    }
    public enum AccreditingBody
    {
        MDCH,
        CARF,
        TJC,
        NCQA,
        URAC,
        CHAP,
        COA,
        AOA,
        Other
    }
    public enum ProfessionalLiabilityStatus
    {
        Active,
        Expired
    }
    public enum AccreditationActionPending
    {
        Yes,
        No,
        NA
    }
    public enum ActionPendingOrgLicence
    {
        Yes,
        No
    }
    public enum CommercialLiabilityStatus
    {
        Active,
        Expired
    }
    public enum CyberLiabilityStatus
    {
        Active,
        Expired
    }
    public enum DisclosureFormStatus
    {
        Active,
        Expired
    }
    public enum OrgAccreditationLimited
    {
        Yes,
        No,
        NA
    }
    public enum OrgDefendantSUDPayment
    {
        Yes,
        No
    }
    public enum OrgInsuranceInitiallyRefused
    {
        Yes,
        No
    }
    public enum OrgMalpracticeClaimsSUD
    {
        Yes,
        No
    }
    public enum OrgMedicaidSanctions
    {
        Yes,
        No
    }
    public enum OrgMedicareSanctions
    {
        Yes,
        No
    }
    public enum W9Status
    {
        Active,
        Expired
    }
    public enum WorkersCompensationStatus
    {
        Active,
        Expired
    }
    public enum CulturalCompetenciesPickList
    {
        Yes,
        No
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace CredentialingProfileAPIDemo.Models
{
    public class CompositeRequest
    {
        [Key]
        public int Id { get; set; }
        public bool allOrNone { get; set; }
        public List<CompositeRequestItem>? compositeRequest { get; set; }
    }
    public class CompositeRequestItem
    {
        public string? method { get; set; }
        public string? url { get; set; }
        public string? referenceId { get; set; }
        public BaseRequestBody? body { get; set; }
    }
    public abstract class BaseRequestBody
    {
        // Define common properties here
    }
}

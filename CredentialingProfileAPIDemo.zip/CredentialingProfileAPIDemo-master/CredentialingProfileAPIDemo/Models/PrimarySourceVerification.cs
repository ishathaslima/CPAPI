﻿namespace CredentialingProfileAPIDemo.Models
{
    // Abstract base class for primary source verifications
    public abstract class PrimarySourceVerification
    {
        public string? Name { get; set; }
        public PSVStatus PSV_Status__c { get; set; }
        public DateTime Creation_Date__c { get; set; }
        public DateTime Completion_Date__c { get; set; }
        public VerifierCredentialingOrganization Verifier_s_Credentialing_Organization__c { get; set; }
        public string? Other_Accred__c { get; set; }
        public string? Provider_Name__c { get; set; }
        public string? Primary_Source_Verifier__c { get; set; }
        public string? Credentialing_Profile__c { get; set; }
        public string? OwnerId { get; set; }
        public LARALicense LARA_License__c { get; set; }
        public bool MDHHS_Sanctioned_Provider_Check__c { get; set; }
        public bool Office_of_Inspector_General_Check__c { get; set; }
        public bool SAM_gov_Check__c { get; set; }
    }
    public enum PSVStatus
    {
        InProgress,
        Complete,
        ExpiredLicensureCertification,
        Expired,
        CVOInProgress
    }
    public enum VerifierCredentialingOrganization
    {
        COA,
        NCQA,
        JointCommission,
        URAC,
        Other,
        CARF,
        None
    }
    public enum LARALicense
    {
        Acupuncture,
        Audiology,
        AddictionMedicine,
        BehaviorAnalysts,
        Counseling,
        GeneticCounseling,
        MarriageAndFamilyTherapy,
        MassageTherapy,
        Medicine,
        Nursing,
        NursingHomeAdministrator,
        OccupationalTherapy,
        OsteopathicMedicineSurgery,
        Pharmacy,
        PhysicalTherapy,
        PhysicianAssistantPA,
        Psychology,
        RespiratoryCare,
        SocialWorker,
        SpeechLanguagePathology,
        NursePractitionerNP,
        Other
    }
}

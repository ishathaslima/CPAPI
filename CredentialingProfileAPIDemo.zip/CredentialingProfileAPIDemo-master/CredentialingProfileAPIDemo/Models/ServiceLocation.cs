﻿using System.ComponentModel.DataAnnotations;

namespace CredentialingProfileAPIDemo.Models
{
    public class ServiceLocation : BaseRequestBody
    {
        public string? Account_Site__c { get; set; }
        public string? Account__c { get; set; }
        public string? Credentialing_Profile__c { get; set; }
        public bool Facility_License_if_applicable__c { get; set; }
        public DateTime? Facility_License_Expiration_if_applicab__c { get; set; }
        public string? Facility_License_Number_if_applicable__c { get; set; }
        public string? Facility_License_Status_if_applicable__c { get; set; }
        public string? Hours_of_Operation__c { get; set; }
        public AccommodationsAccessibility Accomodations_Accessibility__c { get; set; }
        public string? Accomodations_Accessibility_Other__c { get; set; }
        public bool Licensed_Facility__c { get; set; }
    }
    public enum AccommodationsAccessibility
    {
        AccessibleAlarms,
        AccessibleDrinkingFountains,
        AccessibleEntrance,
        AccessibleParking,
        AccessibleRoute,
        AccessibleTelephones,
        Accessibletreatmentrooms,
        Accessiblerestrooms,
        Automaticdoorsdoorbell,
        ElevatorornoSteps,
        Grabbarsinrestrooms,
        Handicapaccessibleofficebuilding,
        HearingImpaired,
        Intercomsinresidentialbathrooms,
        Interpretersavailable,
        Reasonableaccommodations,
        SpeechImpaired,
        VisuallyImpaired,
        Wheelchair,
        None,
        Other
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace CredentialingProfileAPIDemo.Models
{
    public class CredentialingContact : BaseRequestBody
    {
        public string? Contact_Email__c { get; set; }
        public string? Contact_First_Name__c { get; set; }
        public string? Contact_Last_Name__c { get; set; }
        public ContactPersonRole Contact_Person_Role__c { get; set; }
        public string? Contact_Phone__c { get; set; }
        public bool? Primary_Contact__c { get; set; }
        public string? Credentialing_Profile_Id__c { get; set; }
    }
    public enum ContactPersonRole
    {
        PrimaryContact,
        ComplianceOfficer, 
        QualityImprovementOfficer, 
        CredentialingContact,
        ProgramManager,
        RecipientRightsOfficer,
        CEO,
        CFO,
        CustomerService 
    }
}

﻿namespace CredentialingProfileAPIDemo.Models
{
    public class PractitionerCredentialingProfile : CredentialingProfile
    {
        public string? First_Name__c { get; set; }
        public string? Last_Name__c { get; set; }
        public DateTime Date_of_Birth__c { get; set; }
        public long Medicare_Number__c { get; set; }
        public long Practitioner_NPI__c { get; set; }
        public string? Home_Address_Street_1__c { get; set; }
        public string? Home_Address_Street_2__c { get; set; }
        public string? Home_Address_City__c { get; set; }
        public string? Home_Address_Zipcode__c { get; set; }
        public string? Home_Address_State__c { get; set; }
        public string? Home_Address_County__c { get; set; }
        public string? Other_Specialty__c { get; set; }
        public bool Certificate_of_Liability__c { get; set; }
        public DateTime Certificate_of_Liability_Expiration_Date__c { get; set; }
        public string? Current_Malpractice_Insurance_Coverage__c { get; set; }
        public string? Explanation_Current_Malpractice__c { get; set; }
        public bool File_Malpractice_Insurance_Coverage__c { get; set; }
        public DateTime MalpracticeInsurance_Coverage_Expiration__c { get; set; }
        public string? Languages_Spoken__c { get; set; }
        public string? Cultural_Competences__c { get; set; }
        public bool Five_year_work_history__c { get; set; }
        public AccreditationActionPending X6_month_gap_in_employment_since_profess__c { get; set; }
        public DateTime X6_Month_Gap_Start_Date__c { get; set; }
        public DateTime X6_Month_Gap_End_Date__c { get; set; }
        public string? X6_Month_Gap_Activity__c { get; set; }
        public string? X6_Month_Gap_Reason__c { get; set; }
        public bool Can_you_perform_the_essential_duties_of__c { get; set; }
        public string? Reason_for_inability_to_perform_essentia__c { get; set; }
        public bool Lack_of_present_illegal_drug_use__c { get; set; }
        public string? Explanation_Lackofpresentillegaldrug__c { get; set; }
        public bool History_of_loss_of_license__c { get; set; }
        public string? ExplanationHistoryoflossoflicense__c { get; set; }
        public string? History_of_felony_convictions__c { get; set; }
        public string? ExplanationHistory_of_felony_convictions__c { get; set; }
        public string? History_of_loss_or_limitations_of_privil__c { get; set; }
        public string? ExplanationHistory_of_loss__c { get; set; }
        public CulturalCompetenciesPickList Cultural_Competencies_Picklist__c { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace CredentialingProfileAPIDemo.Models
{
    public class Education : CredentialingProfile
    {
        public string? College_University_Program_Address__c { get; set; }
        public string? College_University_Program_Name__c { get; set; }
        public string? Credentialing_Profile_ID__c { get; set; }
        public string? Degree__c { get; set; }
        public DateTime Graduation_Date__c { get; set; }
    }
}

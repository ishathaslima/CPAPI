﻿using System.ComponentModel.DataAnnotations;

namespace CredentialingProfileAPIDemo.Models
{
    public class ServiceLocationLicense : BaseRequestBody
    {
        public string? Service_Locations__c { get; set; }
        public string? Service_Name__c { get; set; }
        public string? Credentialing_Profile__c { get; set; }
        public DateTime? Service_License_Expiration_if_applicabl__c { get; set; }
        public string? Service_License_Number_if_applicable__c { get; set; }
        public string? Service_License_Status_if_applicable__c { get; set; }
    }
}

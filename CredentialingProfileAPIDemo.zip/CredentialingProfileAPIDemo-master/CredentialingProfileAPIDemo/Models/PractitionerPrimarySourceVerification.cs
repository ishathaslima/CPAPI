﻿namespace CredentialingProfileAPIDemo.Models
{
    public class PractitionerPrimarySourceVerification : PrimarySourceVerification
    {
        public bool Ichat_Background_Check__c { get; set; }
        public bool Workforce_Background_Check__c { get; set; }
        public bool Medicare_Base_Enrollment__c { get; set; }
        public bool Medicare_Opt_Out__c { get; set; }
        public bool LARA_Uploaded__c { get; set; }
        public bool Official_Transcript_from_Accredited_Scho__c { get; set; }
        public bool Degree_Verification__c { get; set; }
        public bool ECFMG__c { get; set; }
        public bool AMA_Verification__c { get; set; }
        public bool AOA_Verification__c { get; set; }
        public bool MCBAP_Verification__c { get; set; }
        public bool MI_Public_Sex_Offender_Registry_Check__c { get; set; }
        public bool National_Sex_Offender_Registry_Check__c { get; set; }
    }
}

﻿namespace CredentialingProfileAPIDemo.Models
{
    public class OrganizationalPrimarySourceVerification : PrimarySourceVerification
    {
        public bool Proof_of_Accreditation__c { get; set; }
        public bool Disciplinary_status_with_regulatory_boar__c { get; set; }
        public bool At_least_five_year_history_of_organizati__c { get; set; }
        public bool On_Site_Quality_Assessment_Recredential__c { get; set; }
    }
}

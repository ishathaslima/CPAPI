﻿using System.ComponentModel.DataAnnotations;

namespace CredentialingProfileAPIDemo.Models
{
    public class Account
    {

        //public Attributes? attributes { get; set; }
        //public string? Id { get; set; }
        public string? Name { get; set; }
        public ShippingAddress? ShippingAddress { get; set; }
        //public bool isAgency__c { get; set; }
        //public bool isSite__c { get; set; }
        //public bool isCMHSP__c { get; set; }
    }
    public class ShippingAddress
    {
        public string? city { get; set; }
        public string? country { get; set; }
        //public string? geocodeAccuracy { get; set; }
        //public double latitude { get; set; }
        //public double longitude { get; set; }
        public string? postalCode { get; set; }
        public string? state { get; set; }
        public string? street { get; set; }
    }
}

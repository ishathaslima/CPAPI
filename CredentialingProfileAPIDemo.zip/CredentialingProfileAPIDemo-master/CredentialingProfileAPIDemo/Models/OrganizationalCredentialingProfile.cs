﻿namespace CredentialingProfileAPIDemo.Models
{
    public class OrganizationalCredentialingProfile : CredentialingProfile
    {
        public bool CVO_Credentialing_Profile__c { get; set; }
        public DateTime Accreditation_End__c { get; set; }
        public DateTime Accreditation_Start__c { get; set; }
        public string? Accrediting_Body_Other__c { get; set; }
        public AccreditingBody Accrediting_Body__c { get; set; }
        public AccreditationActionPending Action_pending_current_accreditation__c { get; set; }
        public ActionPendingOrgLicence Action_pending_org_license__c { get; set; }
        public string? At_least_five_year_history_of_organizati__c { get; set; }
        public string? Attestation_by_the_applicant_of_the_corr__c { get; set; }
        public DateTime Commercial_Liability_Expiration__c { get; set; }
        public bool Commercial_Liability__c { get; set; }
        public CommercialLiabilityStatus Commercial_Liability_Status__c { get; set; }
        public DateTime Cyber_Liability_Expiration_if_applicab__c { get; set; }
        public bool Cyber_Liability_if_applicable__c { get; set; }
        public CyberLiabilityStatus Cyber_Liability_Status_if_applicable__c { get; set; }
        public DateTime Disclosure_Form_Expiration__c { get; set; }
        public bool Disclosure_Form__c { get; set; }
        public DisclosureFormStatus Disclosure_Form_Status__c { get; set; }
        public string? Email__c { get; set; }
        public bool Enrollment_in_Medicaid__c { get; set; }
        public bool Enrollment_in_Medicare__c { get; set; }
        public string? Explanation_current_accreditation__c { get; set; }
        public string? Explanation_five_year_history__c { get; set; }
        public OrgAccreditationLimited Explanation_org_accreditation_limited__c { get; set; }
        public string? Explanation_org_defendant_SUD_payment__c { get; set; }
        public string? Explanation_org_insurance_initially_refu__c { get; set; }
        public string? Explanation_org_license__c { get; set; }
        public string? Explanation_org_malpractice_claims_SUD__c { get; set; }
        public string? Explanation_org_medicaid_sanctions__c { get; set; }
        public string? Explanation_org_medicare_sanctions__c { get; set; }
        public string? Five_year_history_org_liability__c { get; set; }
        public string? Group_Affiliation__c { get; set; }
        public string? Has_the_organization_ever_had_its_accred__c { get; set; }
        public bool Is_the_organization_accredited__c { get; set; }
        public long NPI__c { get; set; }
        public string? Office_Fax_Number__c { get; set; }
        public string? Office_Phone_Number__c { get; set; }
        public string? Office_Secondary_Phone_Number__c { get; set; }
        public OrgAccreditationLimited Org_accreditation_limited__c { get; set; }
        public OrgDefendantSUDPayment Org_defendant_SUD_payment__c { get; set; }
        public OrgInsuranceInitiallyRefused Org_insurance_initially_refused__c { get; set; }
        public OrgMalpracticeClaimsSUD Org_malpractice_claims_SUD__c { get; set; }
        public OrgMedicaidSanctions Org_medicaid_sanctions__c { get; set; }
        public OrgMedicareSanctions Org_medicare_sanctions__c { get; set; }
        public bool Please_indicate_if_you_have_a_speciality__c { get; set; }
        public bool Please_indicate_whether_interpretation_s__c { get; set; }
        public DateTime Professional_Liability_Expiration__c { get; set; }
        public bool Professional_Liability__c { get; set; }
        public ProfessionalLiabilityStatus Professional_Liability_Status__c { get; set; }
        public DateTime Proof_of_Accreditation_Expiration__c { get; set; }
        public bool Proof_of_Accreditation__c { get; set; }
        public string? Specialties__c { get; set; }
        public string? Specialty_Other__c { get; set; }
        public long Tax_ID__c { get; set; }
        public bool W9__c { get; set; }
        public DateTime W9_Expiration__c { get; set; }
        public W9Status W9_Status__c { get; set; }
        public DateTime When_was_the_last_accreditation_survey__c { get; set; }
        public DateTime Workers_Compensation_Expiration__c { get; set; }
        public bool Workers_Compensation__c { get; set; }
        public WorkersCompensationStatus Workers_Compensation_Status__c { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace CredentialingProfileAPIDemo.Models
{
    public class PostGraduateMedicalTraining : BaseRequestBody
    {
        public string? Credentialing_Profile_Id__c { get; set; }
        public string? Medical_Training_Hospital_Address__c { get; set; }
        public string? Medical_Training_Hospital_Name__c { get; set; }
        public MedicalTrainingType Medical_Training_Type__c { get; set; }
        public string? Specialty__c { get; set; }
        public DateTime Training_End_Date__c { get; set; }
        public DateTime Training_Start_Date__c { get; set; }
    }
    public enum MedicalTrainingType
    {
        Internship,
        Residencies,
        Fellowships,
        Preceptorships
    }
}

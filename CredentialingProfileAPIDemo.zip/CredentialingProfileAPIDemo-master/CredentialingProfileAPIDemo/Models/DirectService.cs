﻿using System.ComponentModel.DataAnnotations;

namespace CredentialingProfileAPIDemo.Models
{
    public class DirectService : CredentialingProfile
    {
        public string? Operator__c { get; set; }
        public string? Service__c { get; set; }
        public bool is_Certification__c { get; set; }
    }
}

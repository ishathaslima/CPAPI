﻿using System.ComponentModel.DataAnnotations;

namespace CredentialingProfileAPIDemo.DBModels
{
    public class ProviderInfo
    {
        [Key]
        public int ProviderId { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? MiddleName { get; set; }
        public string? Title { get; set; }
        public string? Prefix { get; set; }
        public string? Suffix { get; set; }
        public string? Gender { get; set; }
        public DateTime? BirthDate { get; set; }
        public string? SSN { get; set; }
        public string? NPI { get; set; }
        public string? TIN { get; set; }
        public string? ProviderType { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? LastUpdated { get; set; }
        public string? ModUserId { get; set; }
        public string? Specialty { get; set; }
        public string? CAQH { get; set; }
        public string? AssignedUser { get; set; }
        public string? HospitalAffiliation { get; set; }
        public string? TaxonomyCode { get; set; }
        public string? PrimaryBoardCert { get; set; }
        public string? Category { get; set; }
        public string? BoardCertStatus { get; set; }
        public string? TypeDesc { get; set; }
        public string? CredContactName { get; set; }
        public string? NetworkAdequacy { get; set; }
    }
}

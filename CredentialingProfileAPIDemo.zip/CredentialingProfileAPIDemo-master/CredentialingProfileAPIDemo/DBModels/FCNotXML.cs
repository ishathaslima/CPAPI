﻿using System.ComponentModel.DataAnnotations;

namespace CredentialingProfileAPIDemo.DBModels
{
    public class FCNotXML
    {
        [Key]
        public string? PractitionerID { get; set; }
        public string? FirstName { get; set; }
        public string? MiddleName { get; set; }
        public string? LastName { get; set; }
        public string? ProviderType { get; set; }
        public string? DOB { get; set; }
        public string? SSN { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? Organization { get; set; }
        public string? SubOrganization { get; set; }
        public string? LatestAttestDate { get; set; }
        public string? AffiliationName { get; set; }
        public string? AffiliationType { get; set; }
        public string? AttestSelectFlag { get; set; }
        public string? NPI { get; set; }
        public string? RecordStatus { get; set; }
        public string? CreateDate { get; set; }
        public string? Specialty { get; set; }
        public string? SpecialtyRanking { get; set; }
        public string? TaxonomyCode { get; set; }
        public string? Gender { get; set; }
        public string? suffix { get; set; }
        public string? HomeAddressLine1 { get; set; }
        public string? HomeAddressLine2 { get; set; }
        public string? HomeCity { get; set; }
        public string? HomeState { get; set; }
        public string? HomeZip { get; set; }
        public string? HomeCountry { get; set; }
        public string? HomePhoneNumber { get; set; }
        public string? HomeEmail { get; set; }
        public string? PrimaryPracticeAddressLine1 { get; set; }
        public string? PrimaryPracticeAddressLine2 { get; set; }
        public string? PrimaryPracticeCity { get; set; }
        public string? PrimaryPracticeState { get; set; }
        public string? PrimaryPracticeZip { get; set; }
        public string? PrimaryPracticeCountry { get; set; }
        public string? PrimaryPracticeEmailAddress { get; set; }
        public string? PrimaryPracticePhoneNumber { get; set; }
        public string? PrimaryPracticeFaxNumber { get; set; }
        public string? TAXID { get; set; }
        public string? OfficeContactFirstName { get; set; }
        public string? OfficeContactLastName { get; set; }
        public string? OfficeContactEmailAddress { get; set; }        
        public string? OfficeContactPhoneNumber { get; set; }
        public string? OfficeContactFaxNumber { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace CredentialingProfileAPIDemo.DBModels
{
    public class NCQA
    {
        [Key]
        public string? LAST_NAME { get; set; }
        public string? FIRST_NAME { get; set; }
        public string? DEGREE { get; set; }
        public string? Specialty { get; set; }
        public string? Cred_Date { get; set; }
        public string? Cred_Recred { get; set; }
        public string? Doclink { get; set; }
        public string? providerID { get; set; }
        public string? WorkingLinkinVRC { get; set; }
        public DateTime? datecreated { get; set; }
    }
}

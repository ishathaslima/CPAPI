﻿using System.ComponentModel.DataAnnotations;

namespace CredentialingProfileAPIDemo.DBModels
{
    public class AddressInfo
    {
        [Key]
        public int AddressId { get; set; }
        public int? ClientId { get; set; }
        public int? ClientContactId { get; set; }
        public int? ProviderId { get; set; }
        public int? FacilityId { get; set; }
        public int? InquiryId { get; set; }
        public string? AddressType { get; set; }
        public string? AddressLine1 { get; set; }
        public string? AddressLine2 { get; set; }
        public string? City { get; set; }
        public string? StateOrProvince { get; set; }
        public string? PostalCode { get; set; }
        public string? ZipPlus4 { get; set; }
        public string? County { get; set; }
        public string? Country { get; set; }
        public byte? ActiveInd { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? LastUpdated { get; set; }
        public string? ModUserId { get; set; }
        public string? Region { get; set; }
    }
}

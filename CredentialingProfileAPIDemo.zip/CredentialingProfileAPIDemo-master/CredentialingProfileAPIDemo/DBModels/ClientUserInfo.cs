﻿using System.ComponentModel.DataAnnotations;

namespace CredentialingProfileAPIDemo.DBModels
{
    public class ClientUserInfo
    {
        [Key] 
        public int ClientUserId { get; set; }
        public int? ClientId { get; set; }
        public int? UserId { get; set; }
        public byte? ActiveInd { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? LastUpdated { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public string? FirstName { get; set; }
        public string? MiddleName { get; set; }
        public string? LastName { get; set; }
        public string? UserName { get; set; }
        public byte? RequireSQ { get; set; }
        public string? Suffix { get; set; }
        public string? JobTitle { get; set; }
        public string? AltEmail { get; set; }
        public string? AltPhone { get; set; }
        public string? Gender { get; set; }
        public string? MobilePhone { get; set; }
        public string? MiddleInitial { get; set; }
        public string? DelimAddress { get; set; }
    }
}

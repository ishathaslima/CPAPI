﻿using CredentialingProfileAPIDemo.DBModels;
using CredentialingProfileAPIDemo.Models;
using Microsoft.EntityFrameworkCore;

namespace CredentialingProfileAPIDemo.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // DbSet properties for your entities...
        public DbSet<ProviderInfo> ProviderInfo { get; set; }
        public DbSet<AddressInfo> AddressInfo { get; set; }
        public DbSet<ClientUserInfo> ClientUserInfo { get; set; }
        public DbSet<FCNotXML> FCNotXML { get; set; }
        public DbSet<NCQA> NCQA { get; set; }

    }
}

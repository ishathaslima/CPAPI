﻿using CredentialingProfileAPIDemo.Data;
using CredentialingProfileAPIDemo.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CredentialingProfileAPIDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientUserInfoController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ClientUserInfoController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("services/data/v60.0/sobjects/ClientUserInfo/{id}")]

        public async Task<ActionResult<ClientUserInformation>> GetClientUserInfo(int id)
        {
            //providerid = 226443;
            var clientUserInfo=await _context.ClientUserInfo.FirstOrDefaultAsync(x=>x.ClientUserId==id);
            //var providerInfo = await _context.ProviderInfo.FirstOrDefaultAsync(x => x.ProviderId == id);
            //var addressInfo = await _context.AddressInfo.FirstOrDefaultAsync(x => x.ProviderId == id);

            var clientUserInformation = new ClientUserInformation
            {
                ClientUserId=clientUserInfo.ClientUserId,
                ClientId=clientUserInfo.ClientId,
                UserId=clientUserInfo.UserId,
                ActiveInd=clientUserInfo.ActiveInd,
                DateCreated=clientUserInfo.DateCreated,
                LastUpdated=clientUserInfo.LastUpdated,
                EffectiveDate=clientUserInfo.EffectiveDate,
                FirstName= clientUserInfo.FirstName,
                LastName= clientUserInfo.LastName,
                MiddleName = clientUserInfo.MiddleName,
                UserName= clientUserInfo.UserName,
                RequireSQ= clientUserInfo.RequireSQ,
                Suffix = clientUserInfo.Suffix,
                JobTitle= clientUserInfo.JobTitle,
                AltEmail = clientUserInfo.AltEmail,
                AltPhone = clientUserInfo.AltPhone,
                Gender=clientUserInfo.Gender,
                MobilePhone= clientUserInfo.MobilePhone,
                MiddleInitial= clientUserInfo.MiddleInitial,
                DelimAddress=clientUserInfo.DelimAddress
            };

            if (clientUserInformation == null)
            {
                return NotFound();
            }

            return clientUserInformation;
        }
    }
}

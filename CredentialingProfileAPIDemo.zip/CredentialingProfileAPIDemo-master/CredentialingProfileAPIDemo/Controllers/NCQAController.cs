﻿using CredentialingProfileAPIDemo.Data;
using CredentialingProfileAPIDemo.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CredentialingProfileAPIDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NCQAController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public NCQAController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("services/data/v60.0/sobjects/NCQA/{id}")]

        public async Task<ActionResult<NCQAInformation>> GetNCQAInfo(int id)
        {
            //providerid = 226443;
            var nCQA = await _context.NCQA.FirstOrDefaultAsync(x => x.providerID == id.ToString());
            //var providerInfo = await _context.ProviderInfo.FirstOrDefaultAsync(x => x.ProviderId == id);
            //var addressInfo = await _context.AddressInfo.FirstOrDefaultAsync(x => x.ProviderId == id);

            var nCQAInformation = new NCQAInformation
            {
               LAST_NAME=nCQA.LAST_NAME,
               FIRST_NAME=nCQA.FIRST_NAME,
               DEGREE=nCQA.DEGREE,
               Specialty=nCQA.Specialty,
               Cred_Date=nCQA.Cred_Date,
               Cred_Recred=nCQA.Cred_Recred,
               Doclink=nCQA.Doclink,
               providerID=nCQA.providerID,
               WorkingLinkinVRC=nCQA.WorkingLinkinVRC,
               datecreated=nCQA.datecreated

            };

            if (nCQAInformation == null)
            {
                return NotFound();
            }

            return nCQAInformation;
        }
    }
}

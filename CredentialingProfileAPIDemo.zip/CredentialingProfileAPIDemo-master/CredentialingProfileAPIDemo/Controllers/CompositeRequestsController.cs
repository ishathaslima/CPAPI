﻿using CredentialingProfileAPIDemo.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CredentialingProfileAPIDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompositeRequestsController : ControllerBase
    {
        private readonly List<CompositeRequest> _compositeRequests = new List<CompositeRequest>
        {
            new CompositeRequest
            {
                Id = 1,
                allOrNone = true,
                compositeRequest = new List<CompositeRequestItem>
                {
                    new CompositeRequestItem
                    {
                        method = "GET",
                        url = "/services/data/v52.0/sobjects/Credentialing_Contacts__c",
                        referenceId = "CredContact",
                        body = null
                    },
                    new CompositeRequestItem
                    {
                        method = "POST",
                        url = "/services/data/v52.0/sobjects/Credentialing_Contacts__c",
                        referenceId = "CredContact",
                        body = new CredentialingContact
                        {
                            Contact_Email__c = "john.doe@example.com",
                            Contact_First_Name__c = "John",
                            Contact_Last_Name__c = "Doe",
                            Contact_Person_Role__c = ContactPersonRole.PrimaryContact,
                            Contact_Phone__c = "1234567890",
                            Primary_Contact__c = true,
                            Credentialing_Profile_Id__c = "789"
                        }
                    }
                }
            },
            new CompositeRequest
            {
                Id = 2,
                allOrNone = true,
                compositeRequest = new List<CompositeRequestItem>
                {
                    new CompositeRequestItem
                    {
                        method = "GET",
                        url = "/services/data/v59.0/sobjects/Education__c",
                        referenceId = "eduRecord",
                        body = null
                    },
                    new CompositeRequestItem
                    {
                        method = "POST",
                        url = "/services/data/v59.0/sobjects/Education__c",
                        referenceId = "eduRecord",
                        body = new Education
                        {
                            College_University_Program_Address__c = "123 University Ave, City",
                            College_University_Program_Name__c = "Computer Science",
                            Credentialing_Profile_ID__c = "12345",
                            Degree__c = "Bachelor of Science",
                            Graduation_Date__c = new DateTime(2023, 5, 15)
                        }
                    }
                }
            },
            new CompositeRequest
            {
                Id = 3,
                allOrNone = true,
                compositeRequest = new List<CompositeRequestItem>
                {
                    new CompositeRequestItem
                    {
                        method = "GET",
                        url = "/services/data/v52.0/sobjects/Direct_Service__c",
                        referenceId = "DirectService",
                        body = null
                    },
                    new CompositeRequestItem
                    {
                        method = "POST",
                        url = "/services/data/v52.0/sobjects/Direct_Service__c",
                        referenceId = "DirectService",
                        body = new DirectService
                        {
                            Operator__c = "Operator123",
                            Service__c = "ServiceXYZ",
                            is_Certification__c = true
                        }

                    }
                }
            },
            new CompositeRequest
            {
                Id = 4,
                allOrNone = true,
                compositeRequest = new List<CompositeRequestItem>
                {
                    new CompositeRequestItem
                    {
                        method = "GET",
                        url = "/services/data/v52.0/sobjects/Hospital_Affiliations__c",
                        referenceId = "HA1",
                        body = null
                    },
                    new CompositeRequestItem
                    {
                        method = "POST",
                        url = "/services/data/v52.0/sobjects/Hospital_Affiliations__c",
                        referenceId = "HA1",
                        body = new HospitalAffiliation
                        {
                            Credentialing_Profile_Id__c = "54321",
                            Hospital_Affiliation_Address__c = "456 Hospital St, Town",
                            Hospital_Affiliation_Name__c = "Community Hospital",
                            Category_of_Membership__c = "Staff",
                            Start_Date_of_Affiliation__c = new DateTime(2020, 7, 1),
                            End_Date_of_Affiliation__c = new DateTime(2023, 6, 30)
                        }

                    }
                }
            }
        };

        [HttpGet]
        public ActionResult<IEnumerable<CompositeRequest>> Get()
        {
            return Ok(_compositeRequests);
        }

        [HttpGet("{id}")]
        public ActionResult<CompositeRequest> Get(int id)
        {
            var compositeRequest = _compositeRequests.FirstOrDefault(c => c.Id == id);
            if (compositeRequest == null)
            {
                return NotFound();
            }
            return Ok(compositeRequest);
        }

        [HttpPost]
        public ActionResult<CompositeRequest> Post([FromBody] CompositeRequest compositeRequest)
        {
            compositeRequest.Id = _compositeRequests.Count + 1;
            _compositeRequests.Add(compositeRequest);
            return CreatedAtAction(nameof(Get), new { id = compositeRequest.Id }, compositeRequest);
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] CompositeRequest compositeRequest)
        {
            var existingRequest = _compositeRequests.FirstOrDefault(c => c.Id == id);
            if (existingRequest == null)
            {
                return NotFound();
            }
            existingRequest.allOrNone = compositeRequest.allOrNone;
            existingRequest.compositeRequest = compositeRequest.compositeRequest;
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var compositeRequest = _compositeRequests.FirstOrDefault(c => c.Id == id);
            if (compositeRequest == null)
            {
                return NotFound();
            }
            _compositeRequests.Remove(compositeRequest);
            return NoContent();
        }
    }
}

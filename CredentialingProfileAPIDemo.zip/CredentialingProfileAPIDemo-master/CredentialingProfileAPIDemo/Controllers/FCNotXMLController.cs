﻿using CredentialingProfileAPIDemo.Data;
using CredentialingProfileAPIDemo.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.Blazor;

namespace CredentialingProfileAPIDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FCNotXMLController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public FCNotXMLController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("services/data/v60.0/sobjects/FCNotXML/{id}")]

        public async Task<ActionResult<FCNotXMLInformation>> GetFCNotXMLInfo(int id)
        {
            //providerid = 226443;
            var fCNotXML = await _context.FCNotXML.FirstOrDefaultAsync(x => x.PractitionerID == id.ToString());
            //var providerInfo = await _context.ProviderInfo.FirstOrDefaultAsync(x => x.ProviderId == id);
            //var addressInfo = await _context.AddressInfo.FirstOrDefaultAsync(x => x.ProviderId == id);

            var fCNotXMLInformation = new FCNotXMLInformation
            {                
                FirstName = fCNotXML.FirstName,
                LastName = fCNotXML.LastName,
                MiddleName = fCNotXML.MiddleName,                
                Gender = fCNotXML.Gender,
                PractitionerID=fCNotXML.PractitionerID,
                ProviderType=fCNotXML.ProviderType,
                DOB= fCNotXML.DOB,
                SSN= fCNotXML.SSN,
                City= fCNotXML.City,
                State= fCNotXML.State,
                Organization= fCNotXML.Organization,
                SubOrganization= fCNotXML.SubOrganization,
                LatestAttestDate= fCNotXML.LatestAttestDate,
                AffiliationName= fCNotXML.AffiliationName,
                AffiliationType= fCNotXML.AffiliationType,
                AttestSelectFlag= fCNotXML.AttestSelectFlag,
                NPI=    fCNotXML.NPI,
                RecordStatus= fCNotXML.RecordStatus,
                CreateDate= fCNotXML.CreateDate,
                Specialty= fCNotXML.Specialty,
                SpecialtyRanking = fCNotXML.SpecialtyRanking,
                TaxonomyCode = fCNotXML.TaxonomyCode,
                suffix = fCNotXML.suffix,
                HomeAddressLine1= fCNotXML.HomeAddressLine1,
                HomeAddressLine2= fCNotXML.HomeAddressLine2,
                HomeCity= fCNotXML.HomeCity,
                HomeCountry= fCNotXML.HomeCountry,
                HomeEmail= fCNotXML.HomeEmail,
                HomePhoneNumber= fCNotXML.HomePhoneNumber,
                HomeState= fCNotXML.HomeState,
                HomeZip= fCNotXML.HomeZip,
                PrimaryPracticeAddressLine1=fCNotXML.PrimaryPracticeAddressLine1,
                PrimaryPracticeAddressLine2=fCNotXML.PrimaryPracticeAddressLine2,
                PrimaryPracticeCity=fCNotXML.PrimaryPracticeCity,
                PrimaryPracticeCountry=fCNotXML.PrimaryPracticeCountry,
                PrimaryPracticeEmailAddress=fCNotXML.PrimaryPracticeEmailAddress,
                PrimaryPracticeFaxNumber=fCNotXML.PrimaryPracticeFaxNumber,
                PrimaryPracticePhoneNumber=fCNotXML.PrimaryPracticePhoneNumber,
                PrimaryPracticeState=fCNotXML.PrimaryPracticeState,
                PrimaryPracticeZip=fCNotXML.PrimaryPracticeZip,
                OfficeContactEmailAddress=fCNotXML.OfficeContactEmailAddress,
                OfficeContactFaxNumber=fCNotXML.OfficeContactFaxNumber,
                OfficeContactFirstName=fCNotXML.OfficeContactFirstName,
                OfficeContactLastName=fCNotXML.OfficeContactLastName,
                OfficeContactPhoneNumber=fCNotXML.OfficeContactPhoneNumber,
                TAXID= fCNotXML.TAXID

            };

            if (fCNotXMLInformation == null)
            {
                return NotFound();
            }

            return fCNotXMLInformation;
        }
    }
}

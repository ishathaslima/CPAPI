﻿using CredentialingProfileAPIDemo.Data;
using CredentialingProfileAPIDemo.Models;
using CredentialingProfileAPIDemo.DBModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CredentialingProfileAPIDemo.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    public class AccountsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public AccountsController(ApplicationDbContext context)
        {
            _context = context;
        }
        // GET: api/Account/5
        [HttpGet("services/data/v60.0/sobjects/Account/{id}")]

        public async Task<ActionResult<Account>> GetAccount(int id)
        {
            //providerid = 226443;
            var providerInfo = await _context.ProviderInfo.FirstOrDefaultAsync(x => x.ProviderId == id);
            var addressInfo = await _context.AddressInfo.FirstOrDefaultAsync(x => x.ProviderId == id);
           
            var account = new Account
            {

                //attributes = new Attributes
                //{
                //    Type = "Account",
                //    Url = "/services/data/v60.0/sobjects/Account/" + id
                //},

                //Id = id,

                Name = providerInfo.FirstName + " " + providerInfo.LastName,
                ShippingAddress = new ShippingAddress
                {
                    city = addressInfo.City,
                    country = addressInfo.Country,
                    postalCode = addressInfo.PostalCode,
                    state = addressInfo.StateOrProvince,
                    street = addressInfo.AddressLine1 + " " + addressInfo.AddressLine2
                    //geocodeAccuracy = "Address",
                    //latitude = 42.647512,
                    //longitude = -85.287325,

                }
                //,
                //isAgency__c = true,
                //isSite__c = false,
                //isCMHSP__c = false
            };

            if (account == null)
            {
                return NotFound();
            }

            return account;
        }
    }
}

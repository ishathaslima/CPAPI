﻿using CredentialingProfileAPIDemo.Data;
using CredentialingProfileAPIDemo.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CredentialingProfileAPIDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CredentialingProfileController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public CredentialingProfileController(ApplicationDbContext context)
        {
            _context = context;
        }
        [HttpGet("/services/apexrest/api/Credentialing_Profile__c/{id}")]
        public async Task<ActionResult<CredentialingProfile>> GetCredentialingProfileInfo(int id)
        {
            //providerid = 226443;
            var providerInfo = await _context.ProviderInfo.FirstOrDefaultAsync(x => x.ProviderId == id);
            var addressInfo = await _context.AddressInfo.FirstOrDefaultAsync(x => x.ProviderId == id);
            return Ok();
        }
    }
}
